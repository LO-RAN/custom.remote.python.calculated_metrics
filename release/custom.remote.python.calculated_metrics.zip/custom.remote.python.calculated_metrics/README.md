# custom.remote.python.calculated_metrics
Dynatrace ActiveGate extension generating values for a custom metric from a set of existing metrics and a formula

## Inputs
![Example inputs](images/sample_inputs.png)

## Outputs
![Example outputs](images/sample_outputs.png)

